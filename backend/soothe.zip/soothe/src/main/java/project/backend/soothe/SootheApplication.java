package project.backend.soothe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SootheApplication {

	public static void main(String[] args) {
		SpringApplication.run(SootheApplication.class, args);
	}

}
